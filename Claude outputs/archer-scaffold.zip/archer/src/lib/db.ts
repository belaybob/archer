import { PrismaClient } from "@prisma/client";

// Standard Next.js-safe Prisma singleton so hot-reload in dev doesn't open a
// new connection pool per reload. Nothing here is Netlify-specific -- this
// works the same wherever the app is hosted.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = db;
}
